# ******************************************************************************
# Copyright (c) 2019 Analog Devices, Inc.  All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# - Redistributions of source code must retain the above copyright notice, this
#  list of conditions and the following disclaimer.
# - Redistributions in binary form must reproduce the above copyright notice,
#  this list of conditions and the following disclaimer in the documentation
#  and/or other materials provided with the distribution.
# - Modified versions of the software must be conspicuously marked as such.
# - This software is licensed solely and exclusively for use with
#  processors/products manufactured by or for Analog Devices, Inc.
# - This software may not be combined or merged with other code in any manner
#  that would cause the software to become subject to terms and conditions
#  which differ from those listed here.
# - Neither the name of Analog Devices, Inc. nor the names of its contributors
#  may be used to endorse or promote products derived from this software
#  without specific prior written permission.
# - The use of this software may or may not infringe the patent rights of one
#  or more patent holders.  This license does not release you from the
#  requirement that you obtain separate licenses from these patent holders to
#  use this software.
#
# THIS SOFTWARE IS PROVIDED BY ANALOG DEVICES, INC. AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
# NONINFRINGEMENT, TITLE, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL ANALOG DEVICES, INC. OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, PUNITIVE OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, DAMAGES ARISING OUT OF
# CLAIMS OF INTELLECTUAL PROPERTY RIGHTS INFRINGEMENT; PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.
# ******************************************************************************

from enum import unique, Enum

from .. import utils


@unique
class PMCommand(Enum):
    """
    PMCommand Enum
    """
    LOWEST = [0x40]
    SET_DATE_TIME_REQ = [0x42]
    SET_DATE_TIME_RES = [0x43]
    GET_BAT_INFO_REQ = [0x44]
    GET_BAT_INFO_RES = [0x45]
    SET_BAT_THR_REQ = [0x46]
    SET_BAT_THR_RES = [0x47]
    SET_POWER_STATE_REQ = [0x48]
    SET_POWER_STATE_RES = [0x49]
    SYS_INFO_REQ = [0x4A]
    SYS_INFO_RES = [0x4B]
    GET_DATE_TIME_REQ = [0x52]
    GET_DATE_TIME_RES = [0x53]
    GET_MCU_VERSION_REQ = [0x58]
    GET_MCU_VERSION_RES = [0x59]
    GET_LOW_TOUCH_LOGGING_STATUS_REQ = [0x66]
    GET_LOW_TOUCH_LOGGING_STATUS_RES = [0x67]
    SYSTEM_RESET_REQ = [0x76]
    SYSTEM_RESET_RES = [0x77]
    SW_CONTROL_REQ = [0x78]
    SW_CONTROL_RES = [0x79]
    LDO_CONTROL_REQ = [0x7A]
    LDO_CONTROL_RES = [0x7B]
    CHIP_ID_REQ = [0x7C]
    CHIP_ID_RES = [0x7D]
    CAP_SENSE_TEST_REQ = [0x7E]
    CAP_SENSE_TEST_RES = [0x7F]
    ENTER_BOOTLOADER_REQ = [0x80]
    ENTER_BOOTLOADER_RES = [0x81]
    CAP_SENSE_STREAM_DATA = [0x82]
    ACTIVATE_TOUCH_SENSOR_REQ = [0x86]
    ACTIVATE_TOUCH_SENSOR_RES = [0x87]
    DEACTIVATE_TOUCH_SENSOR_REQ = [0x88]
    DEACTIVATE_TOUCH_SENSOR_RES = [0x89]
    FLASH_RESET_REQ = [0x8A]
    FLASH_RESET_RES = [0x8B]
    SYSTEM_HW_RESET_REQ = [0x8C]
    SYSTEM_HW_RESET_RES = [0x8D]
    GET_APPS_HEALTH_REQ = [0x90]
    GET_APPS_HEALTH_RES = [0x91]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class PMStatus(Enum):
    """
    PMStatus Enum
    """
    FIX_STATUS = [0x0]
    LOWEST = [0x40]
    OK = [0x41]
    ERROR_ARGS = [0x42]
    LOW_TOUCH_LOGGING_ALREADY_STARTED = [0x43]
    CONFIG_FILE_NOT_FOUND = [0x44]
    CONFIG_FILE_READ_ERROR = [0x45]
    ENABLE_USER_CONFIG_LOG_FAILED = [0x46]
    USER_CONFIG_LOG_ENABLED = [0x47]
    DISABLE_USER_CONFIG_LOG_FAILED = [0x48]
    USER_CONFIG_LOG_DISABLED = [0x49]
    LOG_STOPPED_THROUGH_BUTTON_A = [0x4A]
    LOW_TOUCH_LOGGING_IN_PROGRESS = [0x4B]
    LOW_TOUCH_LOGGING_NOT_STARTED = [0x4C]
    LOW_TOUCH_MAX_FILE_ERROR = [0x4D]
    LOW_TOUCH_MEMORY_FULL_ERROR = [0x4E]
    ERROR_RESET = [0x4F]
    ENABLE_DCB_CONFIG_LOG_FAILED = [0x50]
    DCB_CONFIG_LOG_ENABLED = [0x51]
    DISABLE_DCB_CONFIG_LOG_FAILED = [0x52]
    DCB_CONFIG_LOG_DISABLED = [0x53]
    ERROR_NOT_CHKD = [0xFF]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class MCUType(Enum):
    """
    MCUType Enum
    """
    MCU_INVALID = [0x0]
    MCU_M3 = [0x1]
    MCU_M4 = [0x2]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class ElectrodeSwitch(Enum):
    """
    ElectrodeSwitch Enum
    """
    AD8233 = [0x0]
    AD5940 = [0x1]
    ADPD4000 = [0x2]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class LDO(Enum):
    """
    LDO Enum
    """
    FS = [0x1]
    OPTICAL = [0x2]
    EPHYZ = [0x3]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class ChipID(Enum):
    """
    ChipID Enum
    """
    ADXL362 = [0x1]
    ADPD4K = [0x2]
    ADP5360 = [0x3]
    AD5940 = [0x4]
    NAND_FLASH = [0x5]
    AD7156 = [0x6]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class BatteryStatus(Enum):
    """
    BatteryStatus Enum
    """
    NOT_AVAIL = [0x0]
    NOT_CHARGING = [0x1]
    CHARGING = [0x2]
    COMPLETE = [0x3]
    CHARGE_LDO_MODE = [0x4]
    CHARGE_TIMER_EXPIRED = [0x5]
    DETECTION = [0x6]
    CHARGE_ERROR = [0x7]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))


class PowerMode(Enum):
    """
    PowerMode Enum
    """
    ACTIVE = [0x0]
    HIBERNATE = [0x2]
    SHUTDOWN = [0x3]

    def __repr__(self):
        return "<%s.%s: %r>" % (self.__class__.__name__, self._name_, utils.convert_int_array_to_hex(self._value_))
