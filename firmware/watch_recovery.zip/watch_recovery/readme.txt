Steps to erase NOR Flash and load only the bootloader on the watch

1. Installations for erasing flash
	• NRF Command Line Tool - download it from: https://www.nordicsemi.com/Products/Development-tools/nRF-Command-Line-Tools/Download

	This will install two binaries of interest nrfjprog.exe and jlink.exe in the path:
	C:\Program Files (x86)\Nordic Semiconductor\nrf-command-line-tools\bin\nrfjprog.exe
	
	C:\Program Files (x86)\SEGGER\JLink

2. Have nrfjprog.exe in the system environment path on the PC.

3. Attach watch with the debug board, flat cable, Segger JLink debugger, connect it to the PC. (Refer to the image: study_watch_jlink_setup.png in the folder )
   Run jlink.exe from command line shell and execute:
	J-Link>power on perm
   If the command executes successfully, exit from the command line shell.

4. Run load_bootloader.bat
	This will load the bootloader on the watch, note that there is arrow icon coming up on the watch display.
	

Steps to load application Fw on the watch

1. Connect watch with USB cable and note the serial COM port number coming on the Device Manager in the PC.

2. Open Application Wavetool and follow the Fw upgrade process.
